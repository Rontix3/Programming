import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import random
import os
import math

class Menu:
    def __init__(self, game):
        self.game = game
        self.active = True
        self.selected_option = 0
        self.options = [
            {"text": "Játék indítása", "action": "start_game"},
            {"text": "Grafikai beállítások", "action": "graphics_options"},
            {"text": "Irányítás", "action": "controls"},
            {"text": "Új játék", "action": "new_game"},
            {"text": "Kilépés", "action": "exit_game"}
        ]
        
        self.submenu_active = False
        self.submenu_options = []
        self.submenu_selected = 0
        
        self.graphics_options = [
            {"text": "FPS: 30", "value": 30},
            {"text": "FPS: 60", "value": 60, "selected": True},
            {"text": "FPS: 120", "value": 120},
            {"text": "Vissza", "action": "back"}
        ]
        
        self.control_options = [
            {"text": "Vissza", "action": "back"}
        ]
        
        self.title_font = None
        self.option_font = None
        self.control_font = None
        self.update_fonts()
        
        # Háttér textúra
        self.background_texture = self.create_menu_background()
        
        # Animáció
        self.animation_offset = 0
        self.animation_speed = 50  # pixel per másodperc
        self.last_time = pygame.time.get_ticks()
    
    def update_fonts(self):
        """Betűtípusok frissítése az ablak méretéhez"""
        font_scale = min(self.game.width / 1200, self.game.height / 800)
        
        # Betűméretek
        self.title_size = max(int(64 * font_scale), 42)  # Kisebb cím
        self.option_size = max(int(40 * font_scale), 28)  # Menüpontok
        self.control_size = max(int(28 * font_scale), 20)  # Info szöveg
        
        self.title_font = pygame.font.Font(None, self.title_size)
        self.option_font = pygame.font.Font(None, self.option_size)
        self.control_font = pygame.font.Font(None, self.control_size)
    
    def create_menu_background(self):
        """Menü háttér textúra létrehozása"""
        size = 256
        surface = pygame.Surface((size, size), pygame.SRCALPHA)
        
        # Gradient háttér
        for y in range(size):
            color_value = int(20 + 10 * math.sin(y / size * math.pi))
            pygame.draw.line(surface, 
                           (color_value, color_value, color_value + 10, 200),
                           (0, y), (size, y))
        
        # Finom mintázat
        for i in range(0, size, 16):
            for j in range(0, size, 16):
                brightness = random.randint(5, 15)
                pygame.draw.rect(surface, 
                               (brightness, brightness, brightness + 5, 50),
                               (i, j, 8, 8))
        
        texture_data = pygame.image.tostring(surface, "RGBA", False)
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, size, size, 0,
                    GL_RGBA, GL_UNSIGNED_BYTE, texture_data)
        
        return texture_id
    
    def update(self):
        """Menü animáció frissítése"""
        current_time = pygame.time.get_ticks()
        dt = (current_time - self.last_time) / 1000.0
        self.last_time = current_time
        
        self.animation_offset += self.animation_speed * dt
        if self.animation_offset > 256:  # A textúra mérete
            self.animation_offset = 0
    
    def handle_input(self, event):
        """Bevitel kezelése"""
        if event.type == KEYDOWN:
            if not self.submenu_active:
                if event.key == K_UP:
                    self.selected_option = (self.selected_option - 1) % len(self.options)
                elif event.key == K_DOWN:
                    self.selected_option = (self.selected_option + 1) % len(self.options)
                elif event.key == K_RETURN or event.key == K_SPACE or event.key == K_e:
                    self.select_option()
                elif event.key == K_ESCAPE:
                    self.game.running = False
            else:
                if event.key == K_UP:
                    if self.submenu_options == self.graphics_options:
                        self.submenu_selected = (self.submenu_selected - 1) % len(self.submenu_options)
                    else:
                        self.submenu_selected = max(0, self.submenu_selected - 1)
                elif event.key == K_DOWN:
                    if self.submenu_options == self.graphics_options:
                        self.submenu_selected = (self.submenu_selected + 1) % len(self.submenu_options)
                    else:
                        self.submenu_selected = min(len(self.submenu_options) - 1, self.submenu_selected + 1)
                elif event.key == K_RETURN or event.key == K_SPACE or event.key == K_e:
                    self.select_submenu_option()
                elif event.key == K_ESCAPE:
                    self.submenu_active = False
                    self.submenu_selected = 0
    
    def select_option(self):
        """Főmenü opció kiválasztása"""
        option = self.options[self.selected_option]
        
        if option["action"] == "start_game":
            self.active = False
            pygame.mouse.set_visible(False)
            pygame.event.set_grab(True)
        elif option["action"] == "graphics_options":
            self.submenu_active = True
            self.submenu_options = self.graphics_options
            self.submenu_selected = 0
        elif option["action"] == "controls":
            self.submenu_active = True
            self.submenu_options = self.control_options
            self.submenu_selected = 0
        elif option["action"] == "new_game":
            self.game.reset_game()
            self.active = False
            pygame.mouse.set_visible(False)
            pygame.event.set_grab(True)
        elif option["action"] == "exit_game":
            self.game.running = False
    
    def select_submenu_option(self):
        """Almenü opció kiválasztása"""
        option = self.submenu_options[self.submenu_selected]
        
        if "action" in option:
            if option["action"] == "back":
                self.submenu_active = False
                self.submenu_selected = 0
        elif "value" in option:
            # FPS beállítása
            for opt in self.graphics_options:
                if "selected" in opt:
                    opt["selected"] = False
            option["selected"] = True
            self.game.target_fps = option["value"]
    
    def render_surface_to_gl(self, surface, pos):
        """Pygame Surface renderelése OpenGL-be"""
        texture_data = pygame.image.tostring(surface, "RGBA", False)
        texture_id = glGenTextures(1)
        
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface.get_width(), surface.get_height(), 
                    0, GL_RGBA, GL_UNSIGNED_BYTE, texture_data)
        
        glColor4f(1, 1, 1, 1)
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex2f(pos[0], pos[1])
        glTexCoord2f(1, 0); glVertex2f(pos[0] + surface.get_width(), pos[1])
        glTexCoord2f(1, 1); glVertex2f(pos[0] + surface.get_width(), pos[1] + surface.get_height())
        glTexCoord2f(0, 1); glVertex2f(pos[0], pos[1] + surface.get_height())
        glEnd()
        
        glDeleteTextures([texture_id])
    
    def render(self):
        """Menü renderelése"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glClearColor(0.05, 0.05, 0.1, 1.0)
        
        # 2D mód
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        gluOrtho2D(0, self.game.width, self.game.height, 0)
        
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        # Háttér
        glBindTexture(GL_TEXTURE_2D, self.background_texture)
        glColor4f(0.8, 0.8, 1.0, 0.3)
        
        tile_size = 256
        tiles_x = int(self.game.width / tile_size) + 2
        tiles_y = int(self.game.height / tile_size) + 2
        
        offset = self.animation_offset
        
        glBegin(GL_QUADS)
        for i in range(tiles_x):
            for j in range(tiles_y):
                x1 = i * tile_size - offset
                y1 = j * tile_size - offset
                x2 = x1 + tile_size
                y2 = y1 + tile_size
                
                tex_x1 = 0
                tex_y1 = 0
                tex_x2 = 1
                tex_y2 = 1
                
                glTexCoord2f(tex_x1, tex_y1); glVertex2f(x1, y1)
                glTexCoord2f(tex_x2, tex_y1); glVertex2f(x2, y1)
                glTexCoord2f(tex_x2, tex_y2); glVertex2f(x2, y2)
                glTexCoord2f(tex_x1, tex_y2); glVertex2f(x1, y2)
        glEnd()
        
        # Átlós csíkok az átlátszósághoz
        glDisable(GL_TEXTURE_2D)
        glColor4f(0.1, 0.1, 0.2, 0.7)
        
        stripe_width = 100
        for i in range(-self.game.height, self.game.width + self.game.height, stripe_width):
            glBegin(GL_QUADS)
            glVertex2f(i, 0)
            glVertex2f(i + stripe_width, 0)
            glVertex2f(i + stripe_width + self.game.height, self.game.height)
            glVertex2f(i + self.game.height, self.game.height)
            glEnd()
        
        glEnable(GL_TEXTURE_2D)
        
        # Cím
        title_text = "KÉPFELAKASZTÓ"
        title_surface = self.title_font.render(title_text, True, (255, 255, 200))
        title_width, title_height = title_surface.get_size()
        title_x = self.game.width // 2 - title_width // 2
        title_y = self.game.height // 6  # Felső rész
        
        # Cím háttere
        title_bg = pygame.Surface((title_width + 60, title_height + 30), pygame.SRCALPHA)
        title_bg.fill((0, 0, 0, 180))
        title_bg_x = self.game.width // 2 - (title_width + 60) // 2
        title_bg_y = title_y - 15
        
        # Menü opciók
        if not self.submenu_active:
            # Főmenü
            menu_start_y = self.game.height // 3  # Cím alatt kezdődik
            option_spacing = 65  # Kisebb távolság, hogy elférjen az új gomb
            
            for i, option in enumerate(self.options):
                option_y = menu_start_y + i * option_spacing
                
                # Opció háttere
                option_text = option["text"]
                option_surface = self.option_font.render(option_text, True, (255, 255, 255))
                option_width, option_height = option_surface.get_size()
                
                option_bg_width = option_width + 40
                option_bg_height = option_height + 20
                option_bg = pygame.Surface((option_bg_width, option_bg_height), pygame.SRCALPHA)
                
                if i == self.selected_option:
                    option_bg.fill((100, 100, 200, 220))
                    # Kiemelés animáció
                    pulse = abs(math.sin(pygame.time.get_ticks() * 0.002)) * 20
                    pygame.draw.rect(option_bg, (150, 150, 255, 180),
                                   (0, 0, option_bg_width, option_bg_height), 
                                   int(3 + pulse))
                else:
                    option_bg.fill((50, 50, 100, 180))
                
                option_bg_x = self.game.width // 2 - option_bg_width // 2
                option_bg_y = option_y - option_bg_height // 2
                
                # Opció szöveg
                color = (255, 255, 200) if i == self.selected_option else (200, 200, 255)
                option_surface = self.option_font.render(option_text, True, color)
                option_x = self.game.width // 2 - option_width // 2
                option_y_pos = option_y - option_height // 2
                
                # Textúra konverzió és renderelés
                if i == 0:  # Csak egyszer rendereljük a címet
                    self.render_surface_to_gl(title_bg, (title_bg_x, title_bg_y))
                    self.render_surface_to_gl(title_surface, (title_x, title_y))
                
                self.render_surface_to_gl(option_bg, (option_bg_x, option_bg_y))
                self.render_surface_to_gl(option_surface, (option_x, option_y_pos))
        
        else:
            # Almenü
            if self.submenu_options == self.graphics_options:
                submenu_title = "GRAFIKAI BEÁLLÍTÁSOK"
            else:
                submenu_title = "IRÁNYÍTÁS"
            
            sub_title_surface = self.option_font.render(submenu_title, True, (200, 200, 255))
            sub_title_width, sub_title_height = sub_title_surface.get_size()
            sub_title_x = self.game.width // 2 - sub_title_width // 2
            sub_title_y = self.game.height // 5
            
            # Almenü cím háttere
            sub_title_bg = pygame.Surface((sub_title_width + 50, sub_title_height + 25), pygame.SRCALPHA)
            sub_title_bg.fill((0, 0, 0, 180))
            sub_title_bg_x = self.game.width // 2 - (sub_title_width + 50) // 2
            sub_title_bg_y = sub_title_y - 12
            
            option_spacing = 60
            menu_start_y = self.game.height // 3
            
            for i, option in enumerate(self.submenu_options):
                option_y = menu_start_y + i * option_spacing
                
                # Opció háttere
                if "selected" in option and option["selected"]:
                    text = "✓ " + option["text"]
                    color = (150, 255, 150)
                else:
                    text = option["text"]
                    color = (255, 255, 200) if i == self.submenu_selected else (200, 200, 255)
                
                # JAVÍTVA: Garantált szóköz a szövegben
                text = text.replace("FPS:", "FPS: ").replace("FPS:  ", "FPS: ")  # Egy szóköz garantálása
                
                option_surface = self.option_font.render(text, True, color)
                option_width, option_height = option_surface.get_size()
                
                option_bg_width = option_width + 40
                option_bg_height = option_height + 20
                option_bg = pygame.Surface((option_bg_width, option_bg_height), pygame.SRCALPHA)
                
                if i == self.submenu_selected:
                    option_bg.fill((100, 100, 200, 220))
                else:
                    option_bg.fill((50, 50, 100, 180))
                
                option_bg_x = self.game.width // 2 - option_bg_width // 2
                option_bg_y = option_y - option_bg_height // 2
                
                option_x = self.game.width // 2 - option_width // 2
                option_y_pos = option_y - option_height // 2
                
                self.render_surface_to_gl(option_bg, (option_bg_x, option_bg_y))
                self.render_surface_to_gl(option_surface, (option_x, option_y_pos))
            
            # Almenü cím
            self.render_surface_to_gl(sub_title_bg, (sub_title_bg_x, sub_title_bg_y))
            self.render_surface_to_gl(sub_title_surface, (sub_title_x, sub_title_y))
            
            # Irányítás információk (csak az irányítás almenüben)
            if self.submenu_options == self.control_options:
                controls = [
                    "W, A, S, D - Mozgás",
                    "Egér - Nézés",
                    "E - Felvesz/Felakaszt",
                    "Q - Eldob",
                    "ESC - Menü/Kilépés",
                    "ENTER - Kiválaszt"
                ]
                
                controls_start_y = menu_start_y + len(self.submenu_options) * option_spacing + 40
                
                for i, control in enumerate(controls):
                    control_surface = self.control_font.render(control, True, (200, 220, 255))
                    control_width, control_height = control_surface.get_size()
                    control_x = self.game.width // 2 - control_width // 2
                    control_y = controls_start_y + i * 35
                    
                    # Kontroll háttere
                    control_bg = pygame.Surface((control_width + 20, control_height + 10), pygame.SRCALPHA)
                    control_bg.fill((0, 0, 0, 120))
                    control_bg_x = self.game.width // 2 - (control_width + 20) // 2
                    control_bg_y = control_y - 5
                    
                    self.render_surface_to_gl(control_bg, (control_bg_x, control_bg_y))
                    self.render_surface_to_gl(control_surface, (control_x, control_y))
    
        # Lábléc
        footer_text = "ESC - Kilépés a menübe"
        footer_surface = self.control_font.render(footer_text, True, (150, 150, 200))
        footer_width, footer_height = footer_surface.get_size()
        footer_x = self.game.width // 2 - footer_width // 2
        footer_y = self.game.height - 70
        
        # Lábléc háttere
        footer_bg = pygame.Surface((footer_width + 30, footer_height + 15), pygame.SRCALPHA)
        footer_bg.fill((0, 0, 0, 150))
        footer_bg_x = self.game.width // 2 - (footer_width + 30) // 2
        footer_bg_y = footer_y - 7
        
        self.render_surface_to_gl(footer_bg, (footer_bg_x, footer_bg_y))
        self.render_surface_to_gl(footer_surface, (footer_x, footer_y))
        
        # Cleanup
        glDisable(GL_BLEND)
        glDisable(GL_TEXTURE_2D)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)
        
        pygame.display.flip()

class FirstPersonPictureHanger:
    def __init__(self):
        pygame.init()
        
        # Ablak mérete
        self.width = 1200
        self.height = 800
        
        # Resizable ablak
        self.screen = pygame.display.set_mode((self.width, self.height), DOUBLEBUF | OPENGL | RESIZABLE)
        pygame.display.set_caption("Képfelakasztó - First Person")
        
        # Játék állapota
        self.running = True
        
        # Menü
        self.menu = Menu(self)
        pygame.mouse.set_visible(True)
        pygame.event.set_grab(False)
        
        # 3D OpenGL beállítások
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        
        # Fény beállítások
        glLightfv(GL_LIGHT0, GL_POSITION, [10, 10, 10, 1])
        glLightfv(GL_LIGHT0, GL_DIFFUSE, [1, 1, 1, 1])
        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.3, 0.3, 0.3, 1])
        
        # Játékos adatai
        self.player_pos = [0, 1.5, 0]  # x, y, z
        self.player_yaw = 0  # vízszintes forgás
        self.player_pitch = 0  # függőleges forgás
        self.player_height = 1.5
        self.player_speed = 5.0
        self.mouse_sensitivity = 0.2
        
        # Játék állapota
        self.carrying = None  # Éppen cipelt kép
        self.pictures = []  # Falon lévő képek
        self.picture_frames = []  # Üres keretek a falon
        self.available_pictures = []  # Padlón/asztalon lévő képek
        self.score = 0
        
        # Asztal és kép magasságok
        self.table_height = 0.8  # Asztal magassága
        self.picture_on_table_height = 0.82  # Kép magassága az asztalon (asztal tetején + 0.02)
        
        # FPS és idő
        self.clock = pygame.time.Clock()
        self.target_fps = 60
        self.current_fps = 60
        self.delta_time = 0
        
        # Betűtípusok - relatív méretek az ablakhoz
        self.base_font_size = 36
        self.base_small_font_size = 24
        self.update_fonts()
        
        # Képek betöltése - 6 különböző kép
        self.image_names = ['apple.png', 'banana.png', 'bird.png', 
                           'cat.png', 'cherry.png', 'hedgehog.png']
        self.textures = {}
        self.load_textures()
        
        # Pálya inicializálása
        self.init_world()
    
    def reset_game(self):
        """Játék visszaállítása kezdeti állapotba"""
        print("\n" + "="*50)
        print("ÚJ JÁTÉK INDÍTÁSA")
        print("="*50)
        
        # Játékos adatai visszaállítása
        self.player_pos = [0, 1.5, 0]
        self.player_yaw = 0
        self.player_pitch = 0
        self.carrying = None
        self.score = 0
        
        # Pálya újrainicializálása
        self.picture_frames = []
        self.available_pictures = []
        self.init_world()
        
        print("Játék visszaállítva kezdeti állapotba!")
        print("="*50)
    
    def update_fonts(self):
        """Betűtípusok frissítése az ablak méretéhez"""
        font_scale = min(self.width / 1200, self.height / 800)
        
        self.font_size = max(int(self.base_font_size * font_scale), 24)
        self.small_font_size = max(int(self.base_small_font_size * font_scale), 18)
        
        self.font = pygame.font.Font(None, self.font_size)
        self.small_font = pygame.font.Font(None, self.small_font_size)
        
        self.hud_margin = max(int(20 * font_scale), 15)
        self.hud_spacing = max(int(30 * font_scale), 25)
        self.hud_bottom_margin = max(int(100 * font_scale), 80)
        self.hud_right_margin = max(int(200 * font_scale), 150)
        self.hud_bottom_info_margin = max(int(40 * font_scale), 30)
        self.hud_right_info_margin = max(int(120 * font_scale), 100)
        self.fps_left_margin = max(int(20 * font_scale), 15)
        self.fps_top_margin = max(int(40 * font_scale), 30)
        
        if self.width < 400 or self.height < 300:
            print(f"⚠️  Figyelem: Az ablak túl kicsi ({self.width}x{self.height}).")
    
    def load_textures(self):
        """Textúrák betöltése"""
        print("\n=== TEXTÚRÁK BETÖLTÉSE ===")
        
        self.wall_texture = self.create_color_texture((0.8, 0.7, 0.6))
        self.floor_texture = self.create_color_texture((0.4, 0.4, 0.4))
        self.ceiling_texture = self.create_color_texture((0.9, 0.9, 0.9))
        self.frame_texture = self.create_color_texture((0.6, 0.4, 0.2))
        
        for img_name in self.image_names:
            try:
                if not os.path.exists(img_name):
                    print(f"✗ {img_name} nem található")
                    continue
                
                original = pygame.image.load(img_name).convert_alpha()
                print(f"✓ {img_name} betöltve")
                
                size = 256
                scaled = pygame.transform.smoothscale(original, (size, size))
                
                texture_data = pygame.image.tostring(scaled, "RGBA", False)
                texture_id = glGenTextures(1)
                glBindTexture(GL_TEXTURE_2D, texture_id)
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, size, size, 0,
                            GL_RGBA, GL_UNSIGNED_BYTE, texture_data)
                
                self.textures[img_name] = texture_id
                
            except Exception as e:
                print(f"✗ Hiba: {img_name} - {e}")
        
        if len(self.textures) == 0:
            print("⚠️  Demonstrációs textúrák létrehozása...")
            self.create_demo_textures()
        
        print(f"Összesen: {len(self.textures)} kép betöltve")
    
    def create_color_texture(self, color):
        """Egyszínű textúra létrehozása"""
        size = 64
        surface = pygame.Surface((size, size), pygame.SRCALPHA)
        surface.fill((int(color[0]*255), int(color[1]*255), int(color[2]*255), 255))
        
        texture_data = pygame.image.tostring(surface, "RGBA", False)
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, size, size, 0,
                    GL_RGBA, GL_UNSIGNED_BYTE, texture_data)
        
        return texture_id
    
    def create_demo_textures(self):
        """Demonstrációs textúrák"""
        names = ['apple.png', 'banana.png', 'bird.png', 
                'cat.png', 'cherry.png', 'hedgehog.png']
        
        colors = [
            (1, 0, 0), (1, 1, 0), (0, 0.5, 1),
            (1, 0.5, 0), (1, 0, 0.5), (0.6, 0.3, 0)
        ]
        
        size = 256
        
        for name, color in zip(names, colors):
            surface = pygame.Surface((size, size), pygame.SRCALPHA)
            
            pygame.draw.circle(surface, 
                             (int(color[0]*255), int(color[1]*255), int(color[2]*255)), 
                             (size//2, size//2), 100)
            
            font = pygame.font.Font(None, 60)
            text = name.split('.')[0].upper()
            text_surf = font.render(text, True, (255, 255, 255))
            text_rect = text_surf.get_rect(center=(size//2, size//2))
            surface.blit(text_surf, text_rect)
            
            texture_data = pygame.image.tostring(surface, "RGBA", False)
            texture_id = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, texture_id)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, size, size, 0,
                        GL_RGBA, GL_UNSIGNED_BYTE, texture_data)
            
            self.textures[name] = texture_id
    
    def init_world(self):
        """Pálya inicializálása"""
        self.room_width = 10
        self.room_depth = 10
        self.room_height = 3
        
        wall_positions = [
            {'wall': 'left', 'x': -4.5, 'z': -3, 'image': None},
            {'wall': 'left', 'x': -4.5, 'z': 0, 'image': None},
            {'wall': 'left', 'x': -4.5, 'z': 3, 'image': None},
            {'wall': 'right', 'x': 4.5, 'z': -3, 'image': None},
            {'wall': 'right', 'x': 4.5, 'z': 0, 'image': None},
            {'wall': 'right', 'x': 4.5, 'z': 3, 'image': None},
        ]
        
        for pos in wall_positions:
            self.picture_frames.append(pos.copy())
        
        table_positions = [
            {'x': -2, 'z': -2},
            {'x': 2, 'z': -2},
            {'x': -2, 'z': 2},
            {'x': 2, 'z': 2},
            {'x': 0, 'z': -3},
            {'x': 0, 'z': 3},
        ]
        
        available_images = list(self.textures.keys())
        random.shuffle(available_images)
        
        num_pictures_needed = len(table_positions)
        if len(available_images) < num_pictures_needed:
            available_images = available_images * (num_pictures_needed // len(available_images) + 1)
            available_images = available_images[:num_pictures_needed]
        
        for i, pos in enumerate(table_positions):
            self.available_pictures.append({
                'x': pos['x'],
                'y': self.picture_on_table_height,
                'z': pos['z'],
                'image': available_images[i],
                'rotation': random.uniform(0, 360)
            })
        
        print(f"\n=== PÁLYA INICIALIZÁLÁSA ===")
        print(f"Létrehozva: {len(self.picture_frames)} üres keret a falakon")
        print(f"Létrehozva: {len(self.available_pictures)} kép az asztalon")
        
        print("\nKépek az asztalon:")
        for i, pic in enumerate(self.available_pictures):
            print(f"  {i+1}. {pic['image'].split('.')[0]} (x={pic['x']:.1f}, z={pic['z']:.1f})")
    
    def setup_camera(self):
        """First-person kamera beállítása"""
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(90, self.width / self.height, 0.1, 100.0)
        
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        
        yaw_rad = math.radians(self.player_yaw)
        pitch_rad = math.radians(self.player_pitch)
        
        look_x = math.sin(yaw_rad) * math.cos(pitch_rad)
        look_y = math.sin(pitch_rad)
        look_z = math.cos(yaw_rad) * math.cos(pitch_rad)
        
        gluLookAt(
            self.player_pos[0], self.player_pos[1], self.player_pos[2],
            self.player_pos[0] + look_x, self.player_pos[1] + look_y, self.player_pos[2] + look_z,
            0, 1, 0
        )
    
    def draw_cube(self, x, y, z, size, texture_id=None):
        """Kocka rajzolása"""
        if texture_id:
            glBindTexture(GL_TEXTURE_2D, texture_id)
        else:
            glDisable(GL_TEXTURE_2D)
        
        half_size = size / 2
        
        glPushMatrix()
        glTranslatef(x, y, z)
        
        glBegin(GL_QUADS)
        
        if texture_id:
            glTexCoord2f(0, 0)
        glVertex3f(-half_size, -half_size, half_size)
        if texture_id:
            glTexCoord2f(1, 0)
        glVertex3f(half_size, -half_size, half_size)
        if texture_id:
            glTexCoord2f(1, 1)
        glVertex3f(half_size, half_size, half_size)
        if texture_id:
            glTexCoord2f(0, 1)
        glVertex3f(-half_size, half_size, half_size)
        
        if texture_id:
            glTexCoord2f(0, 0)
        glVertex3f(-half_size, -half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 0)
        glVertex3f(-half_size, half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 1)
        glVertex3f(half_size, half_size, -half_size)
        if texture_id:
            glTexCoord2f(0, 1)
        glVertex3f(half_size, -half_size, -half_size)
        
        if texture_id:
            glTexCoord2f(0, 0)
        glVertex3f(-half_size, half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 0)
        glVertex3f(-half_size, half_size, half_size)
        if texture_id:
            glTexCoord2f(1, 1)
        glVertex3f(half_size, half_size, half_size)
        if texture_id:
            glTexCoord2f(0, 1)
        glVertex3f(half_size, half_size, -half_size)
        
        if texture_id:
            glTexCoord2f(0, 0)
        glVertex3f(-half_size, -half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 0)
        glVertex3f(half_size, -half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 1)
        glVertex3f(half_size, -half_size, half_size)
        if texture_id:
            glTexCoord2f(0, 1)
        glVertex3f(-half_size, -half_size, half_size)
        
        if texture_id:
            glTexCoord2f(0, 0)
        glVertex3f(-half_size, -half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 0)
        glVertex3f(-half_size, -half_size, half_size)
        if texture_id:
            glTexCoord2f(1, 1)
        glVertex3f(-half_size, half_size, half_size)
        if texture_id:
            glTexCoord2f(0, 1)
        glVertex3f(-half_size, half_size, -half_size)
        
        if texture_id:
            glTexCoord2f(0, 0)
        glVertex3f(half_size, -half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 0)
        glVertex3f(half_size, half_size, -half_size)
        if texture_id:
            glTexCoord2f(1, 1)
        glVertex3f(half_size, half_size, half_size)
        if texture_id:
            glTexCoord2f(0, 1)
        glVertex3f(half_size, -half_size, half_size)
        
        glEnd()
        
        glPopMatrix()
        
        if texture_id:
            glEnable(GL_TEXTURE_2D)
    
    def draw_room(self):
        """Szoba rajzolása"""
        glBindTexture(GL_TEXTURE_2D, self.floor_texture)
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex3f(-self.room_width/2, 0, -self.room_depth/2)
        glTexCoord2f(10, 0); glVertex3f(self.room_width/2, 0, -self.room_depth/2)
        glTexCoord2f(10, 10); glVertex3f(self.room_width/2, 0, self.room_depth/2)
        glTexCoord2f(0, 10); glVertex3f(-self.room_width/2, 0, self.room_depth/2)
        glEnd()
        
        glBindTexture(GL_TEXTURE_2D, self.ceiling_texture)
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex3f(-self.room_width/2, self.room_height, -self.room_depth/2)
        glTexCoord2f(10, 0); glVertex3f(self.room_width/2, self.room_height, -self.room_depth/2)
        glTexCoord2f(10, 10); glVertex3f(self.room_width/2, self.room_height, self.room_depth/2)
        glTexCoord2f(0, 10); glVertex3f(-self.room_width/2, self.room_height, self.room_depth/2)
        glEnd()
        
        glBindTexture(GL_TEXTURE_2D, self.wall_texture)
        
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex3f(-self.room_width/2, 0, -self.room_depth/2)
        glTexCoord2f(1, 0); glVertex3f(self.room_width/2, 0, -self.room_depth/2)
        glTexCoord2f(1, 1); glVertex3f(self.room_width/2, self.room_height, -self.room_depth/2)
        glTexCoord2f(0, 1); glVertex3f(-self.room_width/2, self.room_height, -self.room_depth/2)
        glEnd()
        
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex3f(-self.room_width/2, 0, self.room_depth/2)
        glTexCoord2f(1, 0); glVertex3f(self.room_width/2, 0, self.room_depth/2)
        glTexCoord2f(1, 1); glVertex3f(self.room_width/2, self.room_height, self.room_depth/2)
        glTexCoord2f(0, 1); glVertex3f(-self.room_width/2, self.room_height, self.room_depth/2)
        glEnd()
        
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex3f(-self.room_width/2, 0, -self.room_depth/2)
        glTexCoord2f(1, 0); glVertex3f(-self.room_width/2, 0, self.room_depth/2)
        glTexCoord2f(1, 1); glVertex3f(-self.room_width/2, self.room_height, self.room_depth/2)
        glTexCoord2f(0, 1); glVertex3f(-self.room_width/2, self.room_height, -self.room_depth/2)
        glEnd()
        
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex3f(self.room_width/2, 0, -self.room_depth/2)
        glTexCoord2f(1, 0); glVertex3f(self.room_width/2, 0, self.room_depth/2)
        glTexCoord2f(1, 1); glVertex3f(self.room_width/2, self.room_height, self.room_depth/2)
        glTexCoord2f(0, 1); glVertex3f(self.room_width/2, self.room_height, -self.room_depth/2)
        glEnd()
    
    def draw_picture_frame(self, frame):
        """Képkeret rajzolása a falon"""
        x, z = frame['x'], frame['z']
        wall = frame['wall']
        
        glDisable(GL_TEXTURE_2D)
        glColor3f(0.6, 0.4, 0.2)
        
        frame_width = 1.0
        frame_height = 1.0
        frame_depth = 0.05
        
        y = self.room_height / 2
        
        glPushMatrix()
        
        if wall == 'left':
            glTranslatef(x, y, z)
            glRotatef(90, 0, 1, 0)
        elif wall == 'right':
            glTranslatef(x, y, z)
            glRotatef(-90, 0, 1, 0)
        elif wall == 'front':
            glTranslatef(x, y, z)
        elif wall == 'back':
            glTranslatef(x, y, z)
            glRotatef(180, 0, 1, 0)
        
        glBegin(GL_QUADS)
        glVertex3f(-frame_width/2, -frame_height/2, frame_depth/2)
        glVertex3f(frame_width/2, -frame_height/2, frame_depth/2)
        glVertex3f(frame_width/2, frame_height/2, frame_depth/2)
        glVertex3f(-frame_width/2, frame_height/2, frame_depth/2)
        
        border = 0.1
        glColor3f(0.8, 0.6, 0.3)
        
        glVertex3f(-frame_width/2, frame_height/2 - border, frame_depth/2)
        glVertex3f(frame_width/2, frame_height/2 - border, frame_depth/2)
        glVertex3f(frame_width/2, frame_height/2, frame_depth/2 + 0.05)
        glVertex3f(-frame_width/2, frame_height/2, frame_depth/2 + 0.05)
        
        glEnd()
        
        glPopMatrix()
        glEnable(GL_TEXTURE_2D)
        glColor3f(1, 1, 1)
    
    def draw_picture(self, image_name, is_on_wall=True, pos=None):
        """Kép rajzolása"""
        if image_name not in self.textures:
            return
        
        glBindTexture(GL_TEXTURE_2D, self.textures[image_name])
        
        picture_width = 0.8
        picture_height = 0.8
        
        glPushMatrix()
        
        if is_on_wall:
            if not pos:
                return
                
            x, z = pos['x'], pos['z']
            wall = pos['wall']
            y = self.room_height / 2
            
            glTranslatef(x, y, z)
            
            if wall == 'left':
                glRotatef(90, 0, 1, 0)
            elif wall == 'right':
                glRotatef(-90, 0, 1, 0)
            elif wall == 'back':
                glRotatef(180, 0, 1, 0)
            
            glTranslatef(0, 0, 0.06)
            
            glBegin(GL_QUADS)
            glTexCoord2f(0, 1); glVertex3f(-picture_width/2, -picture_height/2, 0)
            glTexCoord2f(1, 1); glVertex3f(picture_width/2, -picture_height/2, 0)
            glTexCoord2f(1, 0); glVertex3f(picture_width/2, picture_height/2, 0)
            glTexCoord2f(0, 0); glVertex3f(-picture_width/2, picture_height/2, 0)
            glEnd()
            
            glPopMatrix()
            
        else:
            if self.carrying and self.carrying['image'] == image_name:
                glPopMatrix()
                
                glMatrixMode(GL_PROJECTION)
                glPushMatrix()
                glLoadIdentity()
                gluOrtho2D(0, self.width, self.height, 0)
                
                glMatrixMode(GL_MODELVIEW)
                glPushMatrix()
                glLoadIdentity()
                
                center_x = self.width // 2
                center_y = self.height // 2 + 100
                pic_size = 200
                
                glDisable(GL_LIGHTING)
                glEnable(GL_TEXTURE_2D)
                glEnable(GL_BLEND)
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
                
                glBegin(GL_QUADS)
                glTexCoord2f(0, 0); glVertex2f(center_x - pic_size//2, center_y - pic_size//2)
                glTexCoord2f(1, 0); glVertex2f(center_x + pic_size//2, center_y - pic_size//2)
                glTexCoord2f(1, 1); glVertex2f(center_x + pic_size//2, center_y + pic_size//2)
                glTexCoord2f(0, 1); glVertex2f(center_x - pic_size//2, center_y + pic_size//2)
                glEnd()
                
                glDisable(GL_BLEND)
                glEnable(GL_LIGHTING)
                
                glPopMatrix()
                glMatrixMode(GL_PROJECTION)
                glPopMatrix()
                glMatrixMode(GL_MODELVIEW)
                
                return
                
            else:
                if not pos:
                    glPopMatrix()
                    return
                    
                x, y, z = pos['x'], pos['y'], pos['z']
                rotation = pos.get('rotation', 0)
                
                glTranslatef(x, y, z)
                glRotatef(rotation, 0, 1, 0)
                
                glBegin(GL_QUADS)
                glTexCoord2f(0, 0); glVertex3f(-picture_width/2, 0, -picture_height/2)
                glTexCoord2f(1, 0); glVertex3f(picture_width/2, 0, -picture_height/2)
                glTexCoord2f(1, 1); glVertex3f(picture_width/2, 0, picture_height/2)
                glTexCoord2f(0, 1); glVertex3f(-picture_width/2, 0, picture_height/2)
                glEnd()
                
                glPopMatrix()
    
    def check_collision(self, new_x, new_z):
        """Ütközésvizsgálat a falakkal"""
        player_radius = 0.5
        
        if (abs(new_x) > self.room_width/2 - player_radius or 
            abs(new_z) > self.room_depth/2 - player_radius):
            return False
        return True
    
    def get_looking_at(self):
        """Megnézi, hogy a játékos mire néz"""
        yaw_rad = math.radians(self.player_yaw)
        pitch_rad = math.radians(self.player_pitch)
        
        look_x = math.sin(yaw_rad) * math.cos(pitch_rad)
        look_y = math.sin(pitch_rad)
        look_z = math.cos(yaw_rad) * math.cos(pitch_rad)
        
        max_distance = 1.0
        
        for pic in self.available_pictures:
            dx = pic['x'] - self.player_pos[0]
            dy = pic['y'] - self.player_pos[1]
            dz = pic['z'] - self.player_pos[2]
            
            distance = math.sqrt(dx*dx + dy*dy + dz*dz)
            
            if distance < max_distance:
                dot_product = (dx * look_x + dy * look_y + dz * look_z) / distance
                if dot_product > 0.4:
                    return {'type': 'picture', 'object': pic, 'distance': distance}
        
        for frame in self.picture_frames:
            if frame['image']:
                continue
                
            dx = frame['x'] - self.player_pos[0]
            dz = frame['z'] - self.player_pos[2]
            frame_y = self.room_height / 2
            dy = frame_y - self.player_pos[1]
            distance = math.sqrt(dx*dx + dy*dy + dz*dz)
            
            if distance < max_distance:
                dot_product = (dx * look_x + dy * look_y + dz * look_z) / distance
                if dot_product > 0.4:
                    return {'type': 'frame', 'object': frame, 'distance': distance}
        
        return None
    
    def can_hang_picture(self):
        """Visszaadja, hogy tudunk-e felakasztani és melyik keretre"""
        if not self.carrying:
            return None, None
        
        closest_frame = None
        min_distance = float('inf')
        
        for frame in self.picture_frames:
            if frame['image']:
                continue
                
            dx = frame['x'] - self.player_pos[0]
            dz = frame['z'] - self.player_pos[2]
            frame_y = self.room_height / 2
            dy = frame_y - self.player_pos[1]
            distance = math.sqrt(dx*dx + dy*dy + dz*dz)
            
            if distance < min_distance and distance < 1.0:
                min_distance = distance
                closest_frame = frame
        
        return closest_frame, min_distance
    
    def render_hud(self):
        """HUD renderelése"""
        hud_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        
        # FPS számláló
        fps_bg_width = 120
        fps_bg_height = 40
        fps_bg_surf = pygame.Surface((fps_bg_width, fps_bg_height), pygame.SRCALPHA)
        fps_bg_surf.fill((0, 0, 0, 180))
        hud_surface.blit(fps_bg_surf, (self.fps_left_margin - 5, self.fps_top_margin - 5))
        
        fps_color = (0, 255, 100) if self.current_fps >= 30 else (255, 165, 0)
        fps_text = self.font.render(f"FPS: {self.current_fps}", True, fps_color)
        hud_surface.blit(fps_text, (self.fps_left_margin, self.fps_top_margin))
        
        score_y = self.fps_top_margin + self.hud_spacing + 10
        score_bg_width = 240
        score_bg_height = 40
        score_bg_surf = pygame.Surface((score_bg_width, score_bg_height), pygame.SRCALPHA)
        score_bg_surf.fill((0, 0, 0, 150))
        hud_surface.blit(score_bg_surf, (self.fps_left_margin - 5, score_y - 5))
        
        score_text = self.font.render(f"Pontszám: {self.score}/{len(self.picture_frames)}", 
                                     True, (255, 255, 0))
        hud_surface.blit(score_text, (self.fps_left_margin, score_y))
        
        if self.carrying:
            # JAVÍTVA: A "Cipel:" rublikát 20 pixellel lejjebb vittem
            carry_y = score_y + self.hud_spacing + 20  # +20 pixel a pontszámhoz képest
            carry_bg_width = 250
            carry_bg_height = 40
            carry_bg_surf = pygame.Surface((carry_bg_width, carry_bg_height), pygame.SRCALPHA)
            carry_bg_surf.fill((0, 0, 0, 150))
            hud_surface.blit(carry_bg_surf, (self.fps_left_margin - 5, carry_y - 5))
            
            carry_text = self.font.render(f"Cipel: {self.carrying['image'].split('.')[0]}", 
                                         True, (0, 255, 255))
            hud_surface.blit(carry_text, (self.fps_left_margin, carry_y))
        
        looking_at = self.get_looking_at()
        
        if self.carrying:
            closest_frame, distance = self.can_hang_picture()
            if closest_frame:
                hint_bg_width = 200
                hint_bg_height = 50
                hint_bg_surf = pygame.Surface((hint_bg_width, hint_bg_height), pygame.SRCALPHA)
                hint_bg_surf.fill((0, 0, 0, 180))
                hint_bg_rect = hint_bg_surf.get_rect(center=(self.width//2, self.height - self.hud_bottom_margin))
                hud_surface.blit(hint_bg_surf, hint_bg_rect)
                
                hint_text = self.font.render("E - Felakaszt", True, (0, 255, 0))
                hint_rect = hint_text.get_rect(center=(self.width//2, self.height - self.hud_bottom_margin))
                hud_surface.blit(hint_text, hint_rect)
        
        elif looking_at:
            if looking_at['type'] == 'picture' and not self.carrying:
                hint_bg_width = 200
                hint_bg_height = 50
                hint_bg_surf = pygame.Surface((hint_bg_width, hint_bg_height), pygame.SRCALPHA)
                hint_bg_surf.fill((0, 0, 0, 180))
                hint_bg_rect = hint_bg_surf.get_rect(center=(self.width//2, self.height - self.hud_bottom_margin))
                hud_surface.blit(hint_bg_surf, hint_bg_rect)
                
                hint_text = self.font.render("E - Felvesz", True, (0, 255, 0))
                hint_rect = hint_text.get_rect(center=(self.width//2, self.height - self.hud_bottom_margin))
                hud_surface.blit(hint_text, hint_rect)
            elif looking_at['type'] == 'frame' and self.carrying:
                hint_bg_width = 200
                hint_bg_height = 50
                hint_bg_surf = pygame.Surface((hint_bg_width, hint_bg_height), pygame.SRCALPHA)
                hint_bg_surf.fill((0, 0, 0, 180))
                hint_bg_rect = hint_bg_surf.get_rect(center=(self.width//2, self.height - self.hud_bottom_margin))
                hud_surface.blit(hint_bg_surf, hint_bg_rect)
                
                hint_text = self.font.render("E - Felakaszt", True, (0, 255, 0))
                hint_rect = hint_text.get_rect(center=(self.width//2, self.height - self.hud_bottom_margin))
                hud_surface.blit(hint_text, hint_rect)
        
        controls = [
            "W,A,S,D - Mozgás",
            "Egér - Nézés",
            "E - Felvesz/Felakaszt",
            "Q - Eldob",
            "ESC - Menü"
        ]
        
        controls_bg_width = 220
        controls_bg_height = len(controls) * self.hud_spacing + 10
        controls_bg_surf = pygame.Surface((controls_bg_width, controls_bg_height), pygame.SRCALPHA)
        controls_bg_surf.fill((0, 0, 0, 150))
        hud_surface.blit(controls_bg_surf, (self.width - self.hud_right_margin - 10, self.fps_top_margin - 5))
        
        for i, text in enumerate(controls):
            control_text = self.small_font.render(text, True, (200, 200, 255))
            hud_surface.blit(control_text, (self.width - self.hud_right_margin, 
                                          self.fps_top_margin + i * self.hud_spacing))
        
        if self.height > 400:
            pos_bg_width = 250
            pos_bg_height = 35
            pos_bg_surf = pygame.Surface((pos_bg_width, pos_bg_height), pygame.SRCALPHA)
            pos_bg_surf.fill((0, 0, 0, 150))
            hud_surface.blit(pos_bg_surf, (self.hud_margin - 5, self.height - self.hud_bottom_info_margin - 30))
            
            pos_text = self.small_font.render(
                f"Pozíció: ({self.player_pos[0]:.1f}, {self.player_pos[2]:.1f})", 
                True, (100, 255, 100))
            hud_surface.blit(pos_text, (self.hud_margin, self.height - self.hud_bottom_info_margin))
        
        center_x, center_y = self.width // 2, self.height // 2
        cross_size = max(10, min(20, int(self.width * 0.01)))
        pygame.draw.line(hud_surface, (255, 255, 255), 
                        (center_x - cross_size, center_y), (center_x + cross_size, center_y), 2)
        pygame.draw.line(hud_surface, (255, 255, 255), 
                        (center_x, center_y - cross_size), (center_x, center_y + cross_size), 2)
        
        hud_data = pygame.image.tostring(hud_surface, "RGBA", False)
        
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        gluOrtho2D(0, self.width, self.height, 0)
        
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_BLEND)
        
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, self.width, self.height, 0,
                    GL_RGBA, GL_UNSIGNED_BYTE, hud_data)
        
        glColor4f(1, 1, 1, 1)
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0); glVertex2f(0, 0)
        glTexCoord2f(1, 0); glVertex2f(self.width, 0)
        glTexCoord2f(1, 1); glVertex2f(self.width, self.height)
        glTexCoord2f(0, 1); glVertex2f(0, self.height)
        glEnd()
        
        glDeleteTextures([texture_id])
        
        glDisable(GL_BLEND)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)
    
    def render(self):
        """Fő renderelés"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glClearColor(0.1, 0.1, 0.1, 1.0)
        
        self.setup_camera()
        self.draw_room()
        
        glColor3f(0.5, 0.3, 0.1)
        table_positions = [(-2, 0, -2), (2, 0, -2), (-2, 0, 2), (2, 0, 2), (0, 0, -3), (0, 0, 3)]
        for x, y, z in table_positions:
            self.draw_cube(x, y + 0.4, z, 0.6, None)
        
        for frame in self.picture_frames:
            self.draw_picture_frame(frame)
            if frame['image']:
                self.draw_picture(frame['image'], True, frame)
        
        for pic in self.available_pictures:
            if self.carrying is None or pic['image'] != self.carrying.get('image', None):
                self.draw_picture(pic['image'], False, pic)
        
        if self.carrying:
            self.draw_picture(self.carrying['image'], False, None)
        
        self.render_hud()
        
        pygame.display.flip()
    
    def update(self):
        """Játék logika frissítése"""
        self.delta_time = self.clock.get_time() / 1000.0
        
        keys = pygame.key.get_pressed()
        move_x, move_z = 0, 0
        
        yaw_rad = math.radians(self.player_yaw)
        
        if keys[K_w]:
            move_x += math.sin(yaw_rad)
            move_z += math.cos(yaw_rad)
        if keys[K_s]:
            move_x -= math.sin(yaw_rad)
            move_z -= math.cos(yaw_rad)
        if keys[K_a]:
            move_x += math.cos(yaw_rad)
            move_z -= math.sin(yaw_rad)
        if keys[K_d]:
            move_x -= math.cos(yaw_rad)
            move_z += math.sin(yaw_rad)
        
        length = math.sqrt(move_x*move_x + move_z*move_z)
        if length > 0:
            move_x /= length
            move_z /= length
        
        speed = self.player_speed * self.delta_time
        new_x = self.player_pos[0] + move_x * speed
        new_z = self.player_pos[2] + move_z * speed
        
        if self.check_collision(new_x, new_z):
            self.player_pos[0] = new_x
            self.player_pos[2] = new_z
    
    def handle_interaction(self):
        """E billentyű - Interakció"""
        if not self.carrying:
            looking_at = self.get_looking_at()
            if looking_at and looking_at['type'] == 'picture':
                pic = looking_at['object']
                self.carrying = pic.copy()
                self.available_pictures.remove(pic)
                print(f"✓ Felvettél egy képet: {pic['image']}")
                return
        
        if self.carrying:
            closest_frame, distance = self.can_hang_picture()
            if closest_frame:
                if closest_frame['image'] is None:
                    closest_frame['image'] = self.carrying['image']
                    self.score += 1
                    print(f"✓ Felakasztottad a képet: {self.carrying['image']}")
                    print(f"  Keret pozíció: ({closest_frame['x']:.1f}, {closest_frame['z']:.1f})")
                    self.carrying = None
                    
                    filled_frames = len([f for f in self.picture_frames if f['image']])
                    if filled_frames == len(self.picture_frames):
                        print("\n🎉 GRATULÁLOK! Minden kép a helyén van!")
                        print("Nyomd meg az ESC billentyűt a menübe való visszatéréshez!")
                else:
                    print(f"✗ Ez a keret már foglalt: {closest_frame['image']}")
    
    def handle_drop(self):
        """Q billentyű - Eldobás"""
        if self.carrying:
            yaw_rad = math.radians(self.player_yaw)
            drop_distance = 1.5
            
            drop_x = self.player_pos[0] + math.sin(yaw_rad) * drop_distance
            drop_z = self.player_pos[2] + math.cos(yaw_rad) * drop_distance
            
            self.carrying['x'] = drop_x
            self.carrying['z'] = drop_z
            self.carrying['y'] = self.picture_on_table_height
            self.carrying['rotation'] = random.uniform(0, 360)
            self.available_pictures.append(self.carrying)
            print(f"✗ Eldobtad a képet: {self.carrying['image']}")
            self.carrying = None
    
    def run(self):
        """Főciklus"""
        print("\n" + "="*50)
        print("KÉPFELAKASZTÓ JÁTÉK - First Person")
        print("="*50)
        print("Nyomd meg az ESC billentyűt a menü megnyitásához!")
        print("="*50)
        
        while self.running:
            if self.menu.active:
                # Menü mód
                for event in pygame.event.get():
                    if event.type == QUIT:
                        self.running = False
                    elif event.type == VIDEORESIZE:
                        self.width = event.w
                        self.height = event.h
                        self.screen = pygame.display.set_mode((self.width, self.height), 
                                                              DOUBLEBUF | OPENGL | RESIZABLE)
                        glViewport(0, 0, self.width, self.height)
                        self.update_fonts()
                        self.menu.update_fonts()
                    elif event.type == KEYDOWN:
                        if event.key == K_ESCAPE:
                            self.running = False
                        else:
                            self.menu.handle_input(event)
                
                self.menu.update()
                self.menu.render()
                self.clock.tick(60)
                
            else:
                # Játék mód
                for event in pygame.event.get():
                    if event.type == QUIT:
                        self.running = False
                    elif event.type == VIDEORESIZE:
                        self.width = event.w
                        self.height = event.h
                        self.screen = pygame.display.set_mode((self.width, self.height), 
                                                              DOUBLEBUF | OPENGL | RESIZABLE)
                        glViewport(0, 0, self.width, self.height)
                        self.update_fonts()
                    elif event.type == KEYDOWN:
                        if event.key == K_ESCAPE:
                            self.menu.active = True
                            pygame.mouse.set_visible(True)
                            pygame.event.set_grab(False)
                        elif event.key == K_e:
                            self.handle_interaction()
                        elif event.key == K_q:
                            self.handle_drop()
                    elif event.type == MOUSEMOTION:
                        dx, dy = event.rel
                        self.player_yaw -= dx * self.mouse_sensitivity
                        self.player_pitch += dy * self.mouse_sensitivity
                        self.player_pitch = max(-89, min(89, self.player_pitch))
                        pygame.mouse.set_pos(self.width // 2, self.height // 2)
                
                self.update()
                self.render()
                self.current_fps = int(self.clock.get_fps())
                self.clock.tick(self.target_fps)
        
        pygame.quit()

if __name__ == "__main__":
    game = FirstPersonPictureHanger()
    game.run()