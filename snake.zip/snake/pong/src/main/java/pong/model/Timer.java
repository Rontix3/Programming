package pong.model;

import static org.lwjgl.glfw.GLFW.glfwGetTime;

public class Timer {
	
	private double lastLoopTime; 
	private double timeCount;    
	private int fpsCount;        
	private int fps;             

	public void init() {
		lastLoopTime = getTime(); 
	}
	
	public double getTime() {
		return glfwGetTime();
	}
	
	public double getDelta() {
		double time = getTime();
		double delta = time - lastLoopTime;
		lastLoopTime = time;
		timeCount += delta; 
		return delta;
	}
	
	public void updateFPS() {
		fpsCount++; 
	}
	
	public void update() {
		if (timeCount > 1.0) {
			fps = fpsCount; 
			fpsCount = 0;   
			
			timeCount -= 1.0; 
		}
	}
	
	public int getFPS() {
		return fps > 0 ? fps : fpsCount;
	}
	
	
	public double getLastLoopTime() {
		return lastLoopTime;
	}

}