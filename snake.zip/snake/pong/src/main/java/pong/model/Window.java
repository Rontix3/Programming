package pong.model;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.system.MemoryStack.stackPush;
import static org.lwjgl.system.MemoryUtil.NULL;

import java.nio.IntBuffer;

import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.system.MemoryStack;

public class Window {
    private long handle;
    private Timer timer;
    private int width;
    private int height;

public Window(int width, int height, String title) {
    this.width = width;
    this.height = height;
    this.timer = new Timer();

    glfwDefaultWindowHints();
    glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);

    handle = glfwCreateWindow(width, height, title, NULL, NULL);
    if (handle == NULL)
        throw new RuntimeException("Failed to create the GLFW window");


    glfwMakeContextCurrent(handle);
    glfwSwapInterval(1);
    glfwShowWindow(handle);
    
    timer.init();
}

    public void destroy() {
        glfwFreeCallbacks(handle);
        glfwDestroyWindow(handle);
    }
    
    public void clear() {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }

    public void update() {
        try (MemoryStack stack = stackPush()) {
            IntBuffer pWidth = stack.mallocInt(1);
            IntBuffer pHeight = stack.mallocInt(1);
            glfwGetWindowSize(handle, pWidth, pHeight);
            width = pWidth.get(0);
            height = pHeight.get(0);
        }
    }
    
    public void swapBuffers() {
        glfwSwapBuffers(handle);
    }

    public long getHandle() {
        return handle;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
    
    public boolean isOpen() {
        return !glfwWindowShouldClose(handle);
    }
    
    public Timer getTimer() {
        return timer;
    }
    
    public int getFPS() {
        return timer.getFPS();
    }
}