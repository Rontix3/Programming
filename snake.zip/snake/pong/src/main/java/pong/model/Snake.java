package pong.model;

import java.util.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.glfw.GLFW.*;
import pong.math.Vec2;

public class Snake {
    private LinkedList<Vec2> body = new LinkedList<>();
    private Vec2 direction = new Vec2(1, 0);
    private Vec2 nextDirection = new Vec2(1, 0);
    private float moveTimer = 0f;
    private final float moveInterval = 0.12f; 
    private final int tileSize = 10;
    private boolean shouldGrow = false;
    private int score = 0;
    private final Window window;

    private Vec2 renderPosition;
    private Vec2 previousPosition;
    private Vec2 targetPosition;
    private float movementProgress = 0f;

    public Snake(Window window) {
        this.window = window;
        Vec2 startPos = new Vec2(50, 50);
        body.add(startPos);
        renderPosition = new Vec2(startPos.x, startPos.y);
        previousPosition = new Vec2(startPos.x, startPos.y);
        targetPosition = new Vec2(startPos.x, startPos.y);
    }

    public void update(float delta) {
        handleInput();
        moveTimer += delta;

        if (movementProgress < 1f) {
            movementProgress += delta / moveInterval;
            movementProgress = Math.min(movementProgress, 1f);
            
            renderPosition.x = lerp(previousPosition.x, targetPosition.x, movementProgress);
            renderPosition.y = lerp(previousPosition.y, targetPosition.y, movementProgress);
            
            body.getFirst().x = renderPosition.x;
            body.getFirst().y = renderPosition.y;
        }

        if (moveTimer >= moveInterval) {
            commitMove();
            moveTimer = 0f;
        }
    }

    private void commitMove() {
        previousPosition.x = targetPosition.x;
        previousPosition.y = targetPosition.y;
        
        direction.x = nextDirection.x;
        direction.y = nextDirection.y;
        
        targetPosition.x = previousPosition.x + direction.x * tileSize;
        targetPosition.y = previousPosition.y + direction.y * tileSize;
        
        if (!shouldGrow) {
            body.removeLast();
        } else {
            shouldGrow = false;
        }
        
        body.addFirst(new Vec2(targetPosition.x, targetPosition.y));
        movementProgress = 0f;
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * Math.min(Math.max(t, 0), 1);
    }

    public void render() {
        glColor3f(0f, 1f, 0f);
        
        Vec2 head = body.getFirst();
        glBegin(GL_QUADS);
        glVertex2f(head.x, head.y);
        glVertex2f(head.x + tileSize, head.y);
        glVertex2f(head.x + tileSize, head.y + tileSize);
        glVertex2f(head.x, head.y + tileSize);
        glEnd();
        
        for (int i = 1; i < body.size(); i++) {
            Vec2 part = body.get(i);
            glBegin(GL_QUADS);
            glVertex2f(part.x, part.y);
            glVertex2f(part.x + tileSize, part.y);
            glVertex2f(part.x + tileSize, part.y + tileSize);
            glVertex2f(part.x, part.y + tileSize);
            glEnd();
        }
    }

    private void handleInput() {
        if (glfwGetKey(window.getHandle(), GLFW_KEY_UP) == GLFW_PRESS && direction.y != 1)
            nextDirection = new Vec2(0, -1);
        if (glfwGetKey(window.getHandle(), GLFW_KEY_DOWN) == GLFW_PRESS && direction.y != -1)
            nextDirection = new Vec2(0, 1);
        if (glfwGetKey(window.getHandle(), GLFW_KEY_LEFT) == GLFW_PRESS && direction.x != 1)
            nextDirection = new Vec2(-1, 0);
        if (glfwGetKey(window.getHandle(), GLFW_KEY_RIGHT) == GLFW_PRESS && direction.x != -1)
            nextDirection = new Vec2(1, 0);
    }

    public boolean eats(Food food) {
        Vec2 head = body.getFirst();
        return head.x == food.getPos().x && head.y == food.getPos().y;
    }

    public boolean checkCollision() {
        Vec2 head = body.getFirst();
        
        if (head.x < 0 || head.x >= window.getWidth() || head.y < 0 || head.y >= window.getHeight())
            return true;
            
        for (int i = 1; i < body.size(); i++) {
            if (head.x == body.get(i).x && head.y == body.get(i).y)
                return true;
        }
        
        return false;
    }

    public void grow() {
        shouldGrow = true;
        score++;
    }

    public int getScore() {
        return score;
    }
}