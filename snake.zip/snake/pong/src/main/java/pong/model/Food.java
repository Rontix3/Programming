package pong.model;

import static org.lwjgl.opengl.GL11.*;

import pong.math.Vec2;

import java.util.Random;

public class Food {
    private Vec2 pos;
    private final int tileSize = 10;
    private final Window window;
    private final Snake snake;
    private final Random rand = new Random();

    public Food(Window window, Snake snake) {
        this.window = window;
        this.snake = snake;
        respawn();
    }

    public void respawn() {
        int tilesX = window.getWidth() / tileSize;
        int tilesY = window.getHeight() / tileSize;
        this.pos = new Vec2(rand.nextInt(tilesX) * tileSize, rand.nextInt(tilesY) * tileSize);
    }

    public void render() {
        glColor3f(1f, 0f, 0f);
        glBegin(GL_QUADS);
        glVertex2f(pos.x, pos.y);
        glVertex2f(pos.x + tileSize, pos.y);
        glVertex2f(pos.x + tileSize, pos.y + tileSize);
        glVertex2f(pos.x, pos.y + tileSize);
        glEnd();
    }

    public Vec2 getPos() {
        return pos;
    }
}
