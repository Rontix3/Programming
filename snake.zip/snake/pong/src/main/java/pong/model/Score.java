package pong.model;

public class Score {
	public int a = 0, b = 0;
}
