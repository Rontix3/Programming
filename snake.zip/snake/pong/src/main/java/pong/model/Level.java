package pong.model;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

import pong.debug.DebugText; // Importáljuk a DebugText osztályt

public class Level {
    private Snake snake;
    private Food food;
    private final Window window;
    private boolean gameOver = false;
    private Score score; 
    private Timer timer; 


    public Level(Window window, Score score, Timer timer) {
        this.window = window;
        this.score = score;
        this.timer = timer;
    }

    public void init() {
        this.snake = new Snake(window);
        this.food = new Food(window, snake);
        this.gameOver = false;
    }

    public void update(float delta) {
        if (gameOver) {
            if (glfwGetKey(window.getHandle(), GLFW_KEY_R) == GLFW_PRESS) {
                System.out.println("Restarting...");
                init();
            }
            return;
        }

        snake.update(delta); 

       
        if (snake.eats(food)) {
            snake.grow();    
            food.respawn(); 
        }

        if (snake.checkCollision()) {
            System.out.println("Game Over!");
            gameOver = true;
        }
    }

    public void render() {
       
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, window.getWidth(), window.getHeight(), 0, -1, 1);

       
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        snake.render();
        food.render();

        glDisable(GL_DEPTH_TEST);
        glColor3f(1f, 1f, 1f); 

        DebugText.drawText("Score: " + snake.getScore(), 10, 20);
        DebugText.drawText("FPS: " + timer.getFPS(), 10, 40); 

                if (gameOver) {
            DebugText.drawText("GAME OVER - Press R to restart", 60, window.getHeight() / 2);
        }

        glEnable(GL_DEPTH_TEST);
    }
}