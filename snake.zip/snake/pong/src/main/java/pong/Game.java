package pong;

import org.lwjgl.*;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;

import pong.model.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class Game {

    private Timer timer;
    private Level level;
    private Window window;
    private Score score;   
    private final int TARGET_FPS = 60;
    private final double FRAME_TIME = 1.0 / TARGET_FPS;

    public void run() {
        System.out.println("Hello LWJGL " + Version.getVersion() + "!");
        init();
        loop();
        window.destroy();
        glfwTerminate();
        glfwSetErrorCallback(null).free();
        System.out.println("Bye LWJGL " + Version.getVersion() + "!");
    }

    private void init() {
        GLFWErrorCallback.createPrint(System.err).set();
        if (!glfwInit())
            throw new IllegalStateException("Unable to initialize GLFW");

        
        window = new Window(300, 300, "SNAKE");
       
        timer = new Timer();
        score = new Score(); 
       
       
        level = new Level(window, score, timer); 
        level.init();
    }

    private void loop() {
        
        GL.createCapabilities();
      
        glClearColor(0f, 0f, 0f, 0f);
        timer.init(); 

        
        while (window.isOpen()) {
           
            double loopStartTime = timer.getTime();

           
            window.clear();
            window.update();

           
            float delta = (float) timer.getDelta();
           
            level.update(delta);
            level.render();

            
            window.swapBuffers();
            
            glfwPollEvents();

           
            timer.updateFPS();
            timer.update();

           
            double loopEndTime = timer.getTime();
            double elapsedTime = loopEndTime - loopStartTime; 

           
            if (elapsedTime < FRAME_TIME) {
                try {
                    long sleepTimeMs = (long) ((FRAME_TIME - elapsedTime) * 1000);
                    if (sleepTimeMs > 0) {
                        Thread.sleep(sleepTimeMs);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        new Game().run();
    }
}