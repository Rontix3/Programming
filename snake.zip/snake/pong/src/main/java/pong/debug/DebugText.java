package pong.debug;

import java.nio.ByteBuffer;

import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.stb.STBEasyFont;

public class DebugText {
    private static final ByteBuffer charBuffer = ByteBuffer.allocateDirect(9992);

    public static void drawText(String text, float x, float y) {
        if (text == null) return;

        int quads = STBEasyFont.stb_easy_font_print(x, y, text, null, charBuffer);

        glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(2, GL_FLOAT, 16, charBuffer);

        glDrawArrays(GL_QUADS, 0, quads * 4);

        glDisableClientState(GL_VERTEX_ARRAY);
    }
}