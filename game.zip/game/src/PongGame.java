import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.HashSet;
import java.util.Set;

public class PongGame {

    public static final double WIDTH = 800;
    public static final double HEIGHT = 600;
    public static final double PADDLE_W = 15;
    public static final double PADDLE_H = 100;
    public static final double BALL_R = 10;

    double playerY = HEIGHT / 2 - PADDLE_H / 2;
    double botY = HEIGHT / 2 - PADDLE_H / 2;
    double ballX = WIDTH / 2;
    double ballY = HEIGHT / 2;
    double ballXS = 5;
    double ballYS = 5;

    int playerScore = 0;
    int botScore = 0;

    public Set<KeyCode> keys = new HashSet<>();

    private GameMenu menu;

    public PongGame(GameMenu m) {
        menu = m;
    }

    public void resetGame() {
        playerScore = 0;
        botScore = 0;
        resetBall();
        playerY = HEIGHT / 2 - PADDLE_H / 2;
        botY = HEIGHT / 2 - PADDLE_H / 2;
    }

    private void resetBall() {
        double spd = menu.getBallSpeedMultiplier();
        ballX = WIDTH / 2;
        ballY = HEIGHT / 2;
        ballXS = (Math.random() > 0.5 ? 5 : -5) * spd;
        ballYS = (Math.random() > 0.5 ? 5 : -5) * spd;
        System.out.println("ball reset -> " + ballXS + " , " + ballYS);
    }

    public boolean update(long now) {
        if (keys.contains(KeyCode.ESCAPE)) return false;

        if (keys.contains(KeyCode.UP) && playerY > 0) playerY -= 7;
        if (keys.contains(KeyCode.DOWN) && playerY < HEIGHT - PADDLE_H) playerY += 7;

        ballX += ballXS;
        ballY += ballYS;

        if (ballY <= 0 || ballY >= HEIGHT - BALL_R * 2) ballYS *= -1;

        double botCenter = botY + PADDLE_H / 2;
        if (ballY > botCenter + 10) botY += 4.2;
        else if (ballY < botCenter - 10) botY -= 4.2;

        if (ballX <= 40 &&
            ballY + BALL_R * 2 >= playerY &&
            ballY <= playerY + PADDLE_H &&
            ballXS < 0) ballXS = Math.abs(ballXS) + 0.3;

        if (ballX >= WIDTH - 40 &&
            ballY + BALL_R * 2 >= botY &&
            ballY <= botY + PADDLE_H &&
            ballXS > 0) ballXS = -Math.abs(ballXS) - 0.3;

        if (ballX < 0) {
            botScore++;
            resetBall();
        } else if (ballX > WIDTH) {
            playerScore++;
            resetBall();
        }

        return true;
    }

    public void render(GraphicsContext g) {

        g.setFill(Color.BLACK);
        g.fillRect(0, 0, WIDTH, HEIGHT);

        // szaggatott vonal
        g.setFill(Color.GRAY);
        for (int y = 0; y < HEIGHT; y += 30) g.fillRect(WIDTH / 2 - 3, y, 6, 18);

        g.setFill(Color.WHITE);
        g.fillRect(20, playerY, PADDLE_W, PADDLE_H);
        g.fillRect(WIDTH - 20 - PADDLE_W, botY, PADDLE_W, PADDLE_H);

        g.fillOval(ballX, ballY, BALL_R * 2, BALL_R * 2);

        g.setFont(new Font("Monospaced", 60));
        g.fillText(String.valueOf(playerScore), WIDTH / 2 - 80, 70);
        g.fillText(String.valueOf(botScore), WIDTH / 2 + 40, 70);

        g.setFill(Color.YELLOW);
        g.setFont(new Font("Arial", 16));
        g.fillText("FPS: " + (int) Pong.currentFps, 15, 25);

        g.setFill(Color.GRAY);
        g.fillText("ESC = Menu", WIDTH - 140, 25);
    }
}
