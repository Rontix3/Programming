public class Launcher {
    public static void main(String[] args) {
        System.setProperty("prism.verbose", "true");      
        System.setProperty("prism.order", "d3d,es2,sw"); 
        System.setProperty("prism.forceGPU", "true");   

        Pong.main(args);
    }
}
