import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Pong extends Application {

    public static double currentFps = 0;
    private long lastTime = 0;
    private int frames = 0;
    private PongGame game;
    private AnimationTimer loop;
    private Scene gameScene;
    private GameMenu menu;
    public void start(Stage stage) {

        Canvas canvas = new Canvas(PongGame.WIDTH, PongGame.HEIGHT);
        GraphicsContext g = canvas.getGraphicsContext2D();

        menu = new GameMenu(stage);
        game = new PongGame(menu);

        StackPane root = new StackPane(canvas);
        gameScene = new Scene(root);

        gameScene.setOnKeyPressed(e -> game.keys.add(e.getCode()));
        gameScene.setOnKeyReleased(e -> game.keys.remove(e.getCode()));

        loop = new AnimationTimer() {
            public void handle(long now) {
                if (lastTime == 0) lastTime = now;
                frames++;

                if (now - lastTime >= 1_000_000_000) {
                    currentFps = frames;
                    System.out.println("FPS = " + currentFps);
                    frames = 0;
                    lastTime = now;
                }

                boolean running = game.update(now);
                game.render(g);

                if (!running) {
                    stop();
                    menu.showMenu();
                }
            }
        };

        menu.setOnStartGame(this::startGame);
        menu.setOnQuit(stage::close);

        menu.showMenu();
        stage.setResizable(false);
        stage.show();
    }

    private void startGame() {
        System.out.println("startGame() called");

        game.resetGame();

        Stage stage = (Stage) menu.menuScene.getWindow();
        stage.setScene(gameScene);
        game.keys.clear();
        gameScene.getRoot().requestFocus();

        loop.start();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
