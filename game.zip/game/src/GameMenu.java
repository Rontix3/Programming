import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GameMenu {

    public Scene menuScene;
    public Scene settingsScene;

    private Stage stage;
    private double ballSpeedMultiplier = 1.0;
    private Runnable onStartGame;
    private Runnable onQuit;

    public GameMenu(Stage s) {
        stage = s;
        createMenu();
        createSettingsMenu();
    }

    public double getBallSpeedMultiplier() { return ballSpeedMultiplier; }

    private void createMenu() {
        Text title = new Text("PONG");
        title.setFill(Color.WHITE);
        title.setFont(new Font("Monospaced", 75));

        Button startBtn = makeBtn("Start Game");
        Button settingsBtn = makeBtn("Settings");
        Button quitBtn = makeBtn("Quit");

        startBtn.setOnAction(e -> {
            System.out.println("Start game clicked -> speed = " + ballSpeedMultiplier);
            if (onStartGame != null) onStartGame.run();
        });

        settingsBtn.setOnAction(e -> {
            System.out.println("open settings");
            stage.setScene(settingsScene);
        });

        quitBtn.setOnAction(e -> {
            System.out.println("quit!");
            if (onQuit != null) onQuit.run();
            else stage.close();
        });

        VBox box = new VBox(30);
        box.setAlignment(Pos.CENTER);
        box.getChildren().addAll(title, startBtn, settingsBtn, quitBtn);
        box.setStyle("-fx-background-color: black;");

        menuScene = new Scene(box, 800, 600);
    }

    private void createSettingsMenu() {
        Text t = new Text("SETTINGS");
        t.setFill(Color.WHITE);
        t.setFont(new Font("Monospaced", 50));

        Label speedLbl = new Label("Ball Speed: 1.0x");
        speedLbl.setTextFill(Color.WHITE);

        Slider speedSlider = new Slider(0.5, 3.0, 1.0);
        speedSlider.setShowTickLabels(true);

        speedSlider.valueProperty().addListener((o, oldVal, newVal) -> {
            ballSpeedMultiplier = newVal.doubleValue();
            speedLbl.setText(String.format("Ball Speed: %.2fx", ballSpeedMultiplier));
            System.out.println("speed changed -> " + ballSpeedMultiplier);
        });

        Button backBtn = makeBtn("Back to Menu");
        backBtn.setOnAction(e -> {
            System.out.println("back to menu");
            stage.setScene(menuScene);
        });

        VBox v = new VBox(25);
        v.setAlignment(Pos.CENTER);
        v.getChildren().addAll(t, speedLbl, speedSlider, backBtn);
        v.setStyle("-fx-background-color:#111");

        settingsScene = new Scene(v, 800, 600);
    }

    private Button makeBtn(String txt) {
        Button b = new Button(txt);
        b.setFont(new Font("Arial", 20));
        b.setPrefWidth(250);
        b.setStyle("-fx-background-color:#333; -fx-text-fill:white;");

        b.setOnMouseEntered(e -> b.setStyle("-fx-background-color:white; -fx-text-fill:black;"));
        b.setOnMouseExited(e -> b.setStyle("-fx-background-color:#333; -fx-text-fill:white;"));

        return b;
    }

    public void setOnStartGame(Runnable r) { onStartGame = r; }
    public void setOnQuit(Runnable r) { onQuit = r; }

    public void showMenu() {
        stage.setScene(menuScene);
        stage.setTitle("Pong Menu");
        stage.show();
    }
}
